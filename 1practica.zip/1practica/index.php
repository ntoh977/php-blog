  <style type="text/css">
   #content{
    width: 99%;
    margin: 20px auto;
    border: 1px solid #cbcbcb;
    display: flex;
    flex-direction: inherit;
    flex-wrap:wrap;
   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   #img_div{
    width: 40%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid #cbcbcb;
   }
   #img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width: 250px;
    height: 140px;
   }
   body{
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
    
    box-sizing: border-box;
   }
   .imagee img{
    width: 35px;
    height: 27px;
 
   }
</style>

<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

коментарий
  <form method="POST" action="" enctype="multipart/form-data" >
    <input type="hidden" name="size" value="1000000">
  
     <div>
name
        <input type="text" name="name">
    </div>   <div>
email
        <input type="text" name="email">
    </div>
     <div>
   message
        <textarea type="text" name="message"></textarea>
    </div>
        <button type="submit" name="upload_img1">POST</button>
    </div>
  </form>
<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "prictik");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload_img1'])) {


    // Get image name
 $date =  date('F  j,  Y');
    // Get text
    $name = mysqli_real_escape_string($db, $_POST['name']);
   $message = mysqli_real_escape_string($db, $_POST['message']);
$email = mysqli_real_escape_string($db, $_POST['email']);
    // image file directory


    $sql = "INSERT INTO `comments` (name, email, message,date_comments) VALUES ('$name','$email', '$message','$date')";
    // execute query
    mysqli_query($db, $sql);
    if (!mysqli_query($db, $sql)) {
    printf("Сообщение ошибки: %s\n", mysqli_error($db));
}


  }


?>

  <form method="POST" action="" enctype="multipart/form-data" >
    <input type="hidden" name="size" value="1000000">
  <label for="color_text">Choose a cat:</label>

  <select name="cars1" id="cars" >
  <option value="">нет категории</option>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>
</select>
     <div>
     Изображение заднего фона сайта главной страницы
        <input type="file" name="image_back">
    </div>
     <div>
title
        <input type="text" name="title_back">
    </div>
     <div>
   text
        <textarea type="text" name="text_back"></textarea>
    </div>
        <button type="submit" name="upload_img">POST</button>
    </div>
  </form>
<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "prictik");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload_img'])) {


    // Get image name
    $image = $_FILES['image_back']['name'];
    // Get text
    $image_text = mysqli_real_escape_string($db, $_POST['text_back']);
   $title_post = mysqli_real_escape_string($db, $_POST['title_back']);
     $catigor = mysqli_real_escape_string($db, $_POST['cars1']);
    // image file directory
    $target = "images/".basename($image);

    $sql = "INSERT INTO `practika` (img, texts, title,catigory) VALUES ('$image', '$image_text','$title_post','$catigor')";
    // execute query
    mysqli_query($db, $sql);
    
 if (move_uploaded_file($_FILES['image_back']['tmp_name'], $target)) {
        $msg = "Image uploaded successfully";
    }else{
        $msg = "Failed to upload image";
    }


  }


?>
с категориями
  <form method="POST" action="" enctype="multipart/form-data" >
    <input type="hidden" name="size" value="1000000">
  <label for="color_text">Choose a cat:</label>

  <select name="cars" id="cars" >
  <option value="">нет категории</option>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="opel">Opel</option>
  <option value="audi">Audi</option>
</select>
    
        <button type="submit" name="cat">POST</button>
    </div>
  </form>
<?php
$query2=mysqli_query($db,"select * from `practika` WHERE catigory = 'saab'");
$row3 = mysqli_num_rows($query2);
// echo "Количество строк:" . $row3;
print_r($row3);
  $query=mysqli_query($db,"select * from `practika` WHERE catigory = 'volvo'");
    while($row = mysqli_fetch_array($query)) {
             $id = $row['id'];
      echo "<div id='img_div'>";

         echo "<a href='post.php?id=$id'>".$row['title'] ."</a>";
        echo "<img src='images/".$row['img']."' >";
        $text_obrez = "<p>".$row['texts']."</p>";
      echo mb_strimwidth($text_obrez, 0, 50, "...");
      echo "</div>";
     
    }
?>

с категориями
<?php

  $conn=mysqli_connect("localhost","root","","prictik");


  $start=0;
   $limit=3;

      $t=mysqli_query($conn,"select * from `practika`");
      $total=mysqli_num_rows($t);



       if(isset($_GET['id']))
       {
            $id=$_GET['id'] ; 
                            $start=($id-1)*$limit;

                      }
                else
                {
            $id=1;
   }
     $page=ceil($total/$limit);

       $query=mysqli_query($conn,"select * from `practika` limit $start,$limit");
     ?>




<?php

    while($row = mysqli_fetch_array($query)) {
             $id = $row['id'];
      echo "<div id='img_div'>";

         echo "<a href='post.php?id=$id'>".$row['title'] ."</a>";
        echo "<img src='images/".$row['img']."' >";
        $text_obrez = "<p>".$row['texts']."</p>";
      echo mb_strimwidth($text_obrez, 0, 50, "...");
      echo "</div>";
     
    }
{?>


<?php
}

?>
               
<div id="pagination">

 <?php
 for($i=1;$i <= $page;$i++){
 ?>
    <a  href="?id=<?php echo $i ?> "><?php echo $i;?></a>
  <?php
 }
  ?>

</div>